
#ifndef A7_LUXURYROOM_H
#define A7_LUXURYROOM_H

#include "Room.h"

class LuxuryRoom:public Room{
public:
    LuxuryRoom(std::string _room_id, int _room_price);
};

#endif
