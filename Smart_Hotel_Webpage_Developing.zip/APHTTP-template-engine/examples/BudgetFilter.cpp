
#include "BudgetFilter.h"

#include <utility>



using namespace std;

double BudgetFilter::get_reserve_difference_with_average(Reserve* _reserve, double _average)
{
    double xi = 0;
    double pow_of_difference;
    xi = _reserve->get_reserve_price() / _reserve->get_reserve_num();
    pow_of_difference = pow((xi - _average), 2);
    return pow_of_difference * _reserve->get_reserve_num();
}


BudgetFilter::BudgetFilter(std::vector<Reserve*> _user_reserves)
{
    type = "budget_filter";
    user_reserves = std::move(_user_reserves);
}

std::vector<Hotel *> BudgetFilter::apply_filter(std::vector<Hotel *> _all_hotels)
{

    std::vector<Hotel*> filtered_hotel;
    double init = 0;
    double reserves_sum = 0;
    double reserves_average = 0;
    double sigma_pow_of_difference = 0;
    double variance = 0;
    int reserves_num = 0;

    for(auto & user_reserve : user_reserves)
    {
        reserves_sum += user_reserve->get_reserve_price();
        reserves_num += user_reserve->get_reserve_num();
    }
    reserves_average = reserves_sum / reserves_num;

    for(auto & user_reserve : user_reserves)
    {
        sigma_pow_of_difference += get_reserve_difference_with_average(user_reserve, reserves_average);
    }
    variance = sqrt(sigma_pow_of_difference / (reserves_num - 1));

    for(auto & _all_hotel : _all_hotels)
    {
        if(abs(_all_hotel->get_average_room_price() - reserves_average) <= (2 * variance))
            filtered_hotel.push_back(_all_hotel);
    }
    return filtered_hotel;
}



