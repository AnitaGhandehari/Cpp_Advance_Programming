

#ifndef A7_INSUFFICIENTRATINGS_H
#define A7_INSUFFICIENTRATINGS_H

#include <exception>

class InsufficientRatings : public std::exception {
    virtual const char* what() const throw()
    {
        return "Insufficient Ratings\n";
    }
};

#endif
