
#ifndef A7_COMMENT_H
#define A7_COMMENT_H

#include <iostream>

class Comment{
private:
    std::string user_name;
    std::string comment;
public:
    Comment(std::string _user_name, std::string _comment);
    void print_comment_info();
};

#endif
