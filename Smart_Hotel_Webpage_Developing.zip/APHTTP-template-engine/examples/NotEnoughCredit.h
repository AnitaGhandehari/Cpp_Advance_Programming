
#ifndef A7_NOTENOUGHCREDIT_H
#define A7_NOTENOUGHCREDIT_H

#include <exception>

class NotEnoughCredit : public std::exception {
    virtual const char* what() const throw()
    {
        return "Not Enough Credit\n";
    }
};

#endif
