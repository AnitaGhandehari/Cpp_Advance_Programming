
#ifndef A7_STANDARDROOM_H
#define A7_STANDARDROOM_H

#include "Room.h"

class StandardRoom:public Room{
private:
public:
    StandardRoom(std::string _room_id, int _room_price);
};

#endif
