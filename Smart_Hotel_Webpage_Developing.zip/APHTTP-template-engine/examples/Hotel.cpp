
#include "Hotel.h"

using namespace std;



void Hotel::set_hotel_rooms(std::vector<std::string> _all_hotel_info)
{
    string room_id;
    for(int id = 1 ; id <= stoi(_all_hotel_info[9]) ; id++)
    {
        room_id = "s" + to_string(id);
        StandardRoom *standard_room = new StandardRoom(room_id, stoi(_all_hotel_info[13]));
        hotel_rooms.push_back(standard_room);
    }
    standard_room_num = stoi(_all_hotel_info[9]);
    standard_room_price = stoi(_all_hotel_info[13]);

    for(int id = 1 ; id <= stoi(_all_hotel_info[10]) ; id++)
    {
        room_id = "d" + to_string(id);
        DeluxRoom *delux_room = new DeluxRoom(room_id, stoi(_all_hotel_info[14]));
        hotel_rooms.push_back(delux_room);
    }
    deluxe_room_num = stoi(_all_hotel_info[10]);
    deluxe_room_price = stoi(_all_hotel_info[14]);

    for(int id = 1 ; id <= stoi(_all_hotel_info[11]) ; id++)
    {
        room_id = "l" + to_string(id);
        LuxuryRoom *luxury_room = new LuxuryRoom(room_id, stoi(_all_hotel_info[15]));
        hotel_rooms.push_back(luxury_room);
    }
    luxury_room_num = stoi(_all_hotel_info[11]);
    luxury_room_price = stoi(_all_hotel_info[15]);

    for(int id = 1 ; id <= stoi(_all_hotel_info[12]) ; id++)
    {
        room_id = "p" + to_string(id);
        PremiumRoom *premium_room = new PremiumRoom(room_id, stoi(_all_hotel_info[16]));
        hotel_rooms.push_back(premium_room);
    }
    premium_room_num = stoi(_all_hotel_info[12]);
    premium_room_price = stoi(_all_hotel_info[16]);
}

double Hotel::get_average_room_price()
{
    double average = 0;
    int num = 0;
    if(standard_room_price > 0)
    {
        num++;
        average += standard_room_price;
    }
    if(deluxe_room_price > 0)
    {
        num++;
        average += deluxe_room_price;
    }
    if(luxury_room_price > 0)
    {
        num++;
        average += luxury_room_price;
    }
    if(premium_room_price > 0)
    {
        num++;
        average += premium_room_price;
    }
    if(num > 0)
        average = average / num;
    else
        average = 0;
    return average;
}

void Hotel::print_hotel_summary()
{
    double average_price = get_average_room_price();
    cout << unique_id << ' ' << property_name << ' ' << hotel_star_rating << ' ';
    cout << city << ' ' << hotel_rooms.size() << ' ' ;
    std::cout << std::fixed;
    cout << setprecision(2) << average_price << ' ' << endl;
}

void Hotel::print_total_hotel_info()
{
    cout << unique_id << endl;
    cout << property_name << endl;
    cout << "star: " << hotel_star_rating << endl;
    cout << "overview: " << hotel_overview << endl;
    cout << "amenities: ";
    for(int each_amenities = 0 ; each_amenities < property_amenities.size() - 1 ; each_amenities++)
        cout << property_amenities[each_amenities] <<'|';
    cout << property_amenities[property_amenities.size() - 1] << endl;
    cout << "city: " << city << endl;
    std::cout << std::fixed;
    cout << setprecision(2) << "latitude: " << latitude << endl;
    cout << setprecision(2) << "longitude: " << longitude << endl;
    cout << "#rooms: " << standard_room_num << ' ' << deluxe_room_num << ' ';
    cout << luxury_room_num << ' ' << premium_room_num << endl;
    cout << "price: " << standard_room_price << ' ' << deluxe_room_price << ' ';
    cout << luxury_room_price << ' ' << premium_room_price << endl;
}

bool Hotel::check_city(std::string _city)
{
    return (city == _city);
}

bool Hotel::check_hotel_star_range(int _min, int _max)
{
    return hotel_star_rating >= _min && hotel_star_rating <= _max;
}

bool Hotel::check_hotel_price_range(double _min_price, double _max_price)
{
    double average = 0;
    int count = 0;
    vector<double> prices;
    prices.push_back(standard_room_price);
    prices.push_back(deluxe_room_price);
    prices.push_back(luxury_room_price);
    prices.push_back(premium_room_price);
    for(int i = 0 ; i < prices.size() ; i++)
    {
        if(prices[i] > 0)
        count++;
        average += prices[i];
    }
    average = average / count;
    return average >= _min_price && average <= _max_price;
}

vector<Room*> Hotel::manage_hotel_reserve(std::string _type, int _quantity, int _check_in, int _check_out)
{
    vector<Room*> reserved_room;
    vector<Room*> not_seen_room;
    not_seen_room = hotel_rooms;

    for(int i = 0 ; i < _quantity ; i++)
    {
        for(int each_room = 0 ; each_room < not_seen_room.size() ; each_room++)
        {
            if(not_seen_room[each_room]->check_reserve_possibility(_type, _check_in, _check_out))
            {
                reserved_room.push_back(not_seen_room[each_room]);
                not_seen_room.erase(not_seen_room.begin() + each_room);
                break;
            }
        }
    }
    return reserved_room;
}

void Hotel::add_comment(std::string _user_name, std::string _comment)
{
    Comment* comment1 = new Comment(_user_name, _comment);
    hotel_comments.push_back(comment1);
}

void Hotel::print_comments()
{
    for(int each_comment = 0 ; each_comment < hotel_comments.size() ; each_comment++)
        hotel_comments[each_comment]->print_comment_info();
}

void Hotel::add_rating(double _location, double _cleanliness, double _staff, double _facilities, double _value_money, double _overall_rating)
{
    Rating* rating1 = new Rating(_location, _cleanliness, _staff, _facilities, _value_money, _overall_rating);
    rating1->set_hotel_id(unique_id);
    hotel_rating = rating1;
}

void Hotel::calculate_average_rating()
{
    double location_rating = 0;
    double cleanliness_rating = 0;
    double staff_rating = 0;
    double facilities_rating = 0;
    double value_money_rating = 0;
    double overall_rating_rating = 0;
    if(hotel_rating == nullptr)
        throw NotRating();

    location_rating = hotel_rating->get_location_rating();
    cleanliness_rating = hotel_rating->get_cleanliness_rating();
    staff_rating = hotel_rating->get_staff_rating();
    facilities_rating = hotel_rating->get_facilities_rating();
    value_money_rating = hotel_rating->get_value_money_rating();
    overall_rating_rating = hotel_rating->get_overall_rating();

    std::cout << std::fixed;
    cout << "location: " << setprecision(2) << double(location_rating) << endl;
    cout << "cleanliness: " << setprecision(2) << double(cleanliness_rating) << endl;
    cout << "staff: " << setprecision(2) << double(staff_rating) << endl;
    cout << "facilities: " << setprecision(2) << double(facilities_rating) << endl;
    cout << "value_for_money: " << setprecision(2) << double(value_money_rating) << endl;
    cout << "overall_rating: " << setprecision(2) << double(overall_rating_rating) << endl;
}

void Hotel::set_personal_rating_value(std::vector<Rating *> _user_ratings, weights _user_weights)
{
    bool rating_exist = false;
    double weights_sum = 0;
    for(auto & _user_rating : _user_ratings)
    {
        if(_user_rating->get_hotel_id() == unique_id)
        {
            personal_rating = _user_rating->get_overall_rating();
            rating_exist = true;
            break;
        }
    }
    if(!rating_exist)
    {
        weights_sum = _user_weights.location + _user_weights.cleanliness + _user_weights.staff +
                _user_weights.facilities + _user_weights.value_for_money;

        personal_rating =(hotel_rating->get_location_rating() * _user_weights.location +
                        hotel_rating->get_cleanliness_rating() * _user_weights.cleanliness +
                        hotel_rating->get_staff_rating() * _user_weights.staff +
                        hotel_rating->get_facilities_rating() * _user_weights.facilities +
                        hotel_rating->get_value_money_rating() * _user_weights.value_for_money) / weights_sum;
    }
}


