
#ifndef A7_ROOMFILTER_H
#define A7_ROOMFILTER_H

#include "Filter.h"

class RoomFilter: public Filter{
private:
    std::string room_type;
    int quantity;
    int check_in;
    int check_out;
public:
    RoomFilter(std::string _type, int _quantity, int _check_in, int _check_out);
    std::vector<Hotel*> apply_filter(std::vector<Hotel*> _all_hotels) override;
};

#endif
