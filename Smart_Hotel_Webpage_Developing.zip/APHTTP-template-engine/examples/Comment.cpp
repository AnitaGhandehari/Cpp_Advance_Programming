
#include "Comment.h"

using namespace std;

Comment::Comment(std::string _user_name, std::string _comment)
{
    user_name = _user_name;
    comment = _comment;
}

void Comment::print_comment_info()
{
    cout << user_name << ": " << comment << endl;
}