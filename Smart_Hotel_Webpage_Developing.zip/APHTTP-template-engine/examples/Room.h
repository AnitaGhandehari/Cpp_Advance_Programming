
#ifndef A7_ROOM_H
#define A7_ROOM_H

#include <string>
#include <vector>
#include <iostream>
#include "ReserveTime.h"

class Room{
protected:
    int room_price = 0;
    std::string room_id;
    std::vector<ReserveTime*> reserves_time;
public:
    int get_room_price() { return room_price; };
    void add_reserve_time(int _check_in, int _check_out);
    void delete_reserve_time(int _check_in, int _check_out);
    bool check_reserve_possibility(std::string _type, int _check_in, int _check_out);
    void print_id();
};

#endif
