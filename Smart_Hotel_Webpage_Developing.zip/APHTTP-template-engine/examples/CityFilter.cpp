
#include "CityFilter.h"

CityFilter::CityFilter(std::string _city)
{
    type = "city_filter";
    city = _city;
}
std::vector<Hotel*> CityFilter::apply_filter(std::vector<Hotel*> _all_hotels)
{
    std::vector<Hotel*> filtered_hotel;
    for(int each_hotel = 0 ; each_hotel < _all_hotels.size() ; each_hotel++)
    {
        if(_all_hotels[each_hotel]->check_city(city))
            filtered_hotel.push_back(_all_hotels[each_hotel]);
    }
    return filtered_hotel;
}
