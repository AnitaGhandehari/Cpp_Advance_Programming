
#ifndef A7_DELUXROOM_H
#define A7_DELUXROOM_H

#include "Room.h"

class DeluxRoom:public Room{
public:
    DeluxRoom(std::string _room_id, int _room_price);
};

#endif
