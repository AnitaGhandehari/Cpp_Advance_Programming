
#ifndef A7_RESERVE_H
#define A7_RESERVE_H

#include "Hotel.h"
#include "Room.h"

#define SPACE ' '


class Reserve{
private:
    int reserve_id = 0;
    int check_in = 0;
    int check_out = 0;
    std::string type;
    std::vector<Room*> reserve_room;
    Hotel* hotel_of_reserve;
public:
    Reserve(int _check_in, int _check_out, std::string _type ,int _reserve_id, std::vector<Room*> _reserve_room, Hotel* _hotel_of_reserve);
    void print_reserve();
    int get_reserve_id(){ return reserve_id; };
    void delete_reserve_room_time();
    double get_reserve_price();
    int get_reserve_num(){ return reserve_room.size(); };
};

#endif
