
#ifndef A7_PREMIUMROOM_H
#define A7_PREMIUMROOM_H

#include "Room.h"

class PremiumRoom: public Room{
public:
    PremiumRoom(std::string _room_id, int _room_price);
};


#endif
