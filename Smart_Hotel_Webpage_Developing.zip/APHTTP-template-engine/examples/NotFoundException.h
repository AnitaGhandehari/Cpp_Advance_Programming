
#ifndef A7_NOTFOUNDEXCEPTION_H
#define A7_NOTFOUNDEXCEPTION_H

#include <exception>

class NotFoundException : public std::exception{
    virtual const char* what() const throw()
    {
        return "Not Found\n";
    }
};

#endif

