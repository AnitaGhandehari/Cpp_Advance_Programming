
#ifndef A7_BUDGETFILTER_H
#define A7_BUDGETFILTER_H

#include "Filter.h"
#include "Reserve.h"

#include <algorithm>
#include <cmath>
#include <cstdlib>
#include <cstdio>

class BudgetFilter:  public Filter{
private:
    std::vector<Reserve*> user_reserves;
public:
    BudgetFilter(std::vector<Reserve*> _user_reserves);
    std::vector<Hotel*> apply_filter(std::vector<Hotel*> _all_hotels) override;
    static double get_reserve_difference_with_average(Reserve* _reserve, double _average);
};

#endif
