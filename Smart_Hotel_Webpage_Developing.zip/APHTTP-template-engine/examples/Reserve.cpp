
#include "Reserve.h"

#include <utility>

using namespace std;

Reserve::Reserve(int _check_in, int _check_out, std::string _type ,int _reserve_id, std::vector<Room*> _reserve_room, Hotel *_hotel_of_reserve)
{
    type = std::move(_type);
    reserve_id = _reserve_id;
    reserve_room  = std::move(_reserve_room);
    hotel_of_reserve = _hotel_of_reserve;
    check_in = _check_in;
    check_out = _check_out;
}

void Reserve::print_reserve()
{
    int cost = 0;
    cout << "id:" << SPACE << reserve_id << SPACE;
    cout << "hotel:" << SPACE << hotel_of_reserve->get_unique_id() << SPACE;
    cout << "room:" << SPACE << type << SPACE;
    cout << "quantity:" << SPACE << reserve_room.size() << SPACE;
    for(auto & i : reserve_room)
        cost += i->get_room_price();
    cout << "cost:" << SPACE << cost << SPACE;
    cout << "check_in" << SPACE << check_in << SPACE;
    cout << "check_out" << SPACE << check_out << endl;
}

void Reserve::delete_reserve_room_time()
{
    for(auto & each_room : reserve_room)
    {
        each_room->delete_reserve_time(check_in, check_out);
    }
}

double Reserve::get_reserve_price()
{
    return double (reserve_room[0]->get_room_price() * reserve_room.size());
}