
#include "Room.h"

using namespace std;

void Room::add_reserve_time(int _check_in, int _check_out)
{
    ReserveTime* time1 = new ReserveTime(_check_in, _check_out);
    reserves_time.push_back(time1);
}

bool Room::check_reserve_possibility(std::string _type, int _check_in, int _check_out)
{
    bool time_check_error = false;

    if(_type.at(0) == room_id.at(0))
    {
        for(int each_time = 0 ; each_time < reserves_time.size() ; each_time++)
        {
            if(reserves_time[each_time]->check_time(_check_in, _check_out))
                time_check_error = true;
        }
        return !time_check_error;
    }
    else
        return false;
}

void Room::print_id()
{
    cout << room_id << SPACE;
}

void Room::delete_reserve_time(int _check_in, int _check_out)
{
    for(int each_reserve = 0 ; each_reserve < reserves_time.size() ; each_reserve++)
    {
        if(reserves_time[each_reserve]->check_absolute_time_equality(_check_in, _check_out))
            reserves_time.erase(reserves_time.begin() + each_reserve);
    }

}