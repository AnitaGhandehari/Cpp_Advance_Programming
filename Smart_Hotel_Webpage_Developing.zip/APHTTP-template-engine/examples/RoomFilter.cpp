
#include "RoomFilter.h"
using namespace std;

RoomFilter::RoomFilter(std::string _type, int _quantity, int _check_in, int _check_out)
{
    type = "room_filter";
    room_type = _type;
    quantity = _quantity;
    check_in = _check_in;
    check_out = _check_out;
}

std::vector<Hotel *> RoomFilter::apply_filter(std::vector<Hotel *> _all_hotels)
{
    std::vector<Hotel*> filtered_hotel;
    std::vector<Room*> rooms;
    for(int each_hotel = 0 ; each_hotel < _all_hotels.size() ; each_hotel++)
    {
        rooms = _all_hotels[each_hotel]->manage_hotel_reserve(room_type, quantity, check_in, check_out);
        if(rooms.size() == quantity)
            filtered_hotel.push_back(_all_hotels[each_hotel]);
        rooms.clear();
    }
    return filtered_hotel;
}