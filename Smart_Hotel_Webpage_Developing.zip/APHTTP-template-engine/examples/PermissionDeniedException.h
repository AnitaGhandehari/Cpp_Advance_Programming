
#ifndef A7_PERMISSIONDENIEDEXCEPTION_H
#define A7_PERMISSIONDENIEDEXCEPTION_H

#include <exception>

class PermissionDeniedException : public std::exception
{
    virtual const char* what() const throw()
    {
        return "Permission Denied\n";
    }
};


#endif
