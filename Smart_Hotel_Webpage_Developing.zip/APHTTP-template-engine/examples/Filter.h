
#ifndef A7_FILTER_H
#define A7_FILTER_H

#include "Hotel.h"

class Filter{
protected:
    std::string type;
public:
    virtual std::vector<Hotel*> apply_filter(std::vector<Hotel*> _all_hotels) = 0;
    std::string get_type() { return type; };
};

#endif
