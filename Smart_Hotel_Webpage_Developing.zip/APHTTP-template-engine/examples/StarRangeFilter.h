
#ifndef A7_STARRANGEFILTER_H
#define A7_STARRANGEFILTER_H

#include "Filter.h"

class StarRangeFilter:public Filter{
private:
    int min;
    int max;
public:
    StarRangeFilter(int _min, int _max);
    std::vector<Hotel*> apply_filter(std::vector<Hotel*> _all_hotels) override;
};

#endif
