
#include "StarRangeFilter.h"

StarRangeFilter::StarRangeFilter(int _min, int _max)
{
    min = _min;
    max = _max;
    type = "star_filter";
}

std::vector<Hotel*> StarRangeFilter::apply_filter(std::vector<Hotel*> _all_hotels)
{
    std::vector<Hotel*> filtered_hotel;
    for(int each_hotel = 0 ; each_hotel < _all_hotels.size() ; each_hotel++)
    {
        if(_all_hotels[each_hotel]->check_hotel_star_range(min, max))
            filtered_hotel.push_back(_all_hotels[each_hotel]);
    }
    return filtered_hotel;
}
