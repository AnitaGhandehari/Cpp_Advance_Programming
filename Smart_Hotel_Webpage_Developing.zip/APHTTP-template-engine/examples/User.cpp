
#include "User.h"
using namespace std;

double clamp(double input, double low, double high)
{
    if(input > high)
        return high;
    else if(input < low)
        return low;
    else
        return input;
}

User::User(std::string _email, std::string _user_name, unsigned long _password)
{
    email = _email;
    user_name = _user_name;
    password = _password;
    wallet_turnovers.push_back(0);
}

bool User::check_login(std::string _email, unsigned long _password)
{
    return (email == _email && password == _password);
}

void User::increase_user_credit(double _credit)
{
    credit += _credit;
    wallet_turnovers.push_back(credit);
}

void User::print_wallet_turnover(int _count)
{
    if(_count < wallet_turnovers.size())
    {
        for (int turnover_num = (wallet_turnovers.size() - _count - 1); turnover_num < wallet_turnovers.size(); turnover_num++)
            cout << setprecision(0) << wallet_turnovers[turnover_num] << endl;
    }
    else
    {
        for(int turnover_num = (wallet_turnovers.size() - 1) ; turnover_num >= 0 ; turnover_num--)
            cout << setprecision(0) << wallet_turnovers[turnover_num] << endl;
    }
}

void User::add_reserve(int _check_in, int _check_out, std::string _type, vector<Room*> _reserve_room, Hotel* _hotel_of_reserve)
{
    int id = user_reserves.size() + 1;
    Reserve* reserve1 = new Reserve(_check_in, _check_out, _type, id , _reserve_room, _hotel_of_reserve);
    user_reserves.push_back(reserve1);
}

void User::print_reservation()
{
    if(user_reserves.size() <= 0)
        throw EmptyException();
    for(int each_reserve =  (user_reserves.size() - 1) ; each_reserve >= 0 ; each_reserve--)
    {
        user_reserves[each_reserve]->print_reserve();
    }
}

void User::cancel_user_reserve(int _id)
{
    bool id_exist = false;
    for(int each_reserve = 0 ; each_reserve < user_reserves.size() ; each_reserve++)
    {
        if(user_reserves[each_reserve]->get_reserve_id() == _id)
        {
            id_exist = true;
            user_reserves[each_reserve]->delete_reserve_room_time();
            this->increase_user_credit(user_reserves[each_reserve]->get_reserve_price() / 2);
            user_reserves.erase(user_reserves.begin() + each_reserve);
        }
    }
    if(!id_exist)
        throw NotFoundException();
}

void User::decrease_reserve_credit(double _price)
{
    credit -= _price;
    wallet_turnovers.push_back(credit);
}


void User::add_rating(Rating *_rating)
{
    for(int each_rating = 0 ; each_rating < user_reserves.size() ; each_rating++)
    {
        if(user_ratings[each_rating]->get_hotel_id() == _rating->get_hotel_id())
            user_ratings.erase(user_ratings.begin() + each_rating);
    }
    user_ratings.push_back(_rating);
}

void User::print_user_weight()
{
    std::cout << std::fixed;
    cout << "active true" << SPACE;
    cout << "location" <<  SPACE << setprecision(2) << user_weights.location << SPACE;
    cout << "cleanliness" << SPACE << setprecision(2) << user_weights.cleanliness << SPACE;
    cout << "staff" << SPACE << setprecision(2) << user_weights.staff << SPACE;
    cout << "facilities" << SPACE << setprecision(2) << user_weights.facilities << SPACE;
    cout << "value_for_money" << SPACE << setprecision(2) << user_weights.value_for_money << SPACE << endl;
}

void User::calculate_weights()
{
    vector<double> w(5);
    vector<double> d(5);
    vector<double> x(5);
    double y;
    srand (time(NULL));
    for(double & i : w)
    {
        i = rand() % 5 + 1;
    }
    for(int level = 0 ; level < 100 ; level++)
    {
        for(double & i : d)
            i = 0;
        for(auto &each_rating : user_ratings)
        {
            x[0] = each_rating->get_location_rating();
            x[1] = each_rating->get_cleanliness_rating();
            x[2] = each_rating->get_staff_rating();
            x[3] = each_rating->get_facilities_rating();
            x[4] = each_rating->get_value_money_rating();
            y = each_rating->get_overall_rating();
            for(int j = 0 ; j < 5 ; j++)
                d[j] += differentiate(x, w, y, j);
        }
        for(int a = 0 ; a < 5 ; a++)
        {
            w[a] = w[a] - d[a];
            w[a] = clamp(w[a], 1, 5);
        }
    }
    user_weights.location = w[0];
    user_weights.cleanliness = w[1];
    user_weights.staff = w[2];
    user_weights.facilities = w[3];
    user_weights.value_for_money = w[4];
}

double User::differentiate(const vector<double>& _x, vector<double> _w, double _y, int _index)
{
    double epsilon = 0.0001;
    vector<double> w_middle(5);
    w_middle = _w;
    w_middle[_index] += epsilon;
    double differentiate_value = (error_function(_x, w_middle, _y) - error_function(_x, _w, _y)) / epsilon;
    return differentiate_value;
}

double User::error_function(vector<double> _x, vector<double> _w, double _y)
{
    double estimated_rating = weight_function(std::move(_x), std::move(_w));
    double different = estimated_rating - _y;
    double error = pow(different, 2);
    return error;
}

double User::weight_function(vector<double> _x, vector<double> _w)
{
    double sum_of_weights = accumulate(_w.begin(), _w.end(), double(0));
    double estimated_rating = (_x[0] * _w[0] + _x[1] * _w[1] + _x[2] * _w[2] + _x[3] * _w[3] + _x[4] * _w[4]) / sum_of_weights;
    return estimated_rating;
}