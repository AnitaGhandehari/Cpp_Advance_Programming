
#ifndef A7_BADREQUESTEXCEPTION_H
#define A7_BADREQUESTEXCEPTION_H

#include <exception>

class BadRequestException : public std::exception{
    virtual const char* what() const throw()
    {
            return "Bad Request\n";
    }
};


#endif
