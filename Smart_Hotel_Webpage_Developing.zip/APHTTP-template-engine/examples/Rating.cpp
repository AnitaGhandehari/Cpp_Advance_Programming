
#include "Rating.h"

Rating::Rating(double _location, double _cleanliness, double _staff, double _facilities, double _value_money, double _overall_rating)
{
    location = _location;
    cleanliness = _cleanliness;
    staff = _staff;
    facilities = _facilities;
    value_money = _value_money;
    overall_rating = _overall_rating;
}