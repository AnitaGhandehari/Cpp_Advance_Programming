

#ifndef A7_USER_H
#define A7_USER_H

#include <string>
#include <vector>
#include <iostream>
#include "Reserve.h"
#include "EmptyException.h"
#include "NotFoundException.h"

class User{
private:
    std::string email;
    std::string user_name;
    unsigned long password;
    std::vector<double> wallet_turnovers;
    std::vector<Reserve*> user_reserves;
    std::vector<Rating*> user_ratings;
    double credit = 0;
    weights user_weights;
public:
    User(std::string _email, std::string _user_name, unsigned long _password);
    bool check_login(std::string _email,  unsigned long _password);
    void increase_user_credit(double _credit);
    void print_wallet_turnover(int _count);
    void add_reserve(int _check_in, int _check_out, std::string _type, std::vector<Room*> _reserve_room, Hotel* _hotel_of_reserve);
    void print_reservation();
    void cancel_user_reserve(int _id);
    void decrease_reserve_credit(double _price);
    std::string get_user_name(){ return user_name; };
    std::string get_email(){ return email; };
    unsigned long get_password(){ return password; };
    double get_credit() { return credit; };
    std::vector<Reserve*> get_user_reserves() { return user_reserves; };
    std::vector<Rating*> get_user_ratings() { return user_ratings; };
    weights get_user_weights() { return user_weights; };
    void add_rating(Rating* _rating);
    void set_user_weights(weights _user_weights) { user_weights = _user_weights; };
    void print_user_weight();
    double differentiate(const std::vector<double>& _x, std::vector<double> _w, double _y, int _index);
    double error_function(std::vector<double> _x, std::vector<double> _w, double _y);
    double weight_function(std::vector<double> _x, std::vector<double> _w);
    void calculate_weights();
};

#endif
