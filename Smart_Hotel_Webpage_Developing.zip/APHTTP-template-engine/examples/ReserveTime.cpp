
#include "ReserveTime.h"

using namespace std;

ReserveTime::ReserveTime(int _check_in, int _check_out)
{
    check_in = _check_in;
    check_out = _check_out;
}

bool ReserveTime::check_time(int _check_in, int _check_out)
{
    return ((_check_in >= check_in && _check_in <= check_out) || (_check_out >= check_in && _check_out <= check_out));
}

bool ReserveTime::check_absolute_time_equality(int _check_in, int _check_out)
{
    return (check_in == _check_in && check_out == _check_out);
}