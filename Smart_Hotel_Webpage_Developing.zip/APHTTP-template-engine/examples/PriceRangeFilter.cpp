
#include "PriceRangeFilter.h"

PriceRangeFilter::PriceRangeFilter(double _min_price, double _max_price)
{
    min_price = _min_price;
    max_price = _max_price;
    type = "price_filter";
}

std::vector<Hotel *> PriceRangeFilter::apply_filter(std::vector<Hotel *> _all_hotels)
{
    std::vector<Hotel*> filtered_hotel;
    for(int each_hotel = 0 ; each_hotel < _all_hotels.size() ; each_hotel++)
    {
        if(_all_hotels[each_hotel]->check_hotel_price_range(min_price, max_price))
            filtered_hotel.push_back(_all_hotels[each_hotel]);
    }
    return filtered_hotel;
}