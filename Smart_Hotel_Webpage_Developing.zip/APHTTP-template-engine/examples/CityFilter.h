
#ifndef A7_CITYFILTER_H
#define A7_CITYFILTER_H

#include "Filter.h"

class CityFilter: public Filter{
private:
    std::string city;
public:
    CityFilter(std::string _city);
    std::vector<Hotel*> apply_filter(std::vector<Hotel*> _all_hotels) override;
};

#endif
