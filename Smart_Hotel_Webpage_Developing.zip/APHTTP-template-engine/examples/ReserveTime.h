

#ifndef A7_RESERVETIME_H
#define A7_RESERVETIME_H

#include <iostream>

#define SPACE ' '

class ReserveTime{
private:
    int check_in;
    int check_out;
public:
    ReserveTime(int _check_in, int _check_out);
    bool check_time(int _check_in, int _check_out);
    bool check_absolute_time_equality(int _check_in, int _check_out);
};

#endif
