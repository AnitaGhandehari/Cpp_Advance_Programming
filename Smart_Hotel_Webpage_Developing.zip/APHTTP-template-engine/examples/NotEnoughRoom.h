
#ifndef A7_NOTENOUGHROOM_H
#define A7_NOTENOUGHROOM_H

#include <exception>

class NotEnoughRoom : public std::exception {
    virtual const char* what() const throw()
    {
        return "Not Enough Room\n";
    }
};

#endif

