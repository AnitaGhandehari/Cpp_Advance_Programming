
#ifndef A7_RATING_H
#define A7_RATING_H

#include <string>

class Rating{
private:
    std::string hotel_id;
    double location;
    double cleanliness;
    double staff;
    double facilities;
    double value_money;
    double overall_rating;
public:
    Rating(double _location, double _cleanliness, double _staff, double _facilities, double _value_money, double _overall_rating);
    double get_location_rating(){ return location; };
    double get_cleanliness_rating(){ return cleanliness; };
    double get_staff_rating(){ return staff; };
    double get_facilities_rating(){ return facilities; };
    double get_value_money_rating(){ return value_money; };
    double get_overall_rating(){ return overall_rating; };
    std::string get_hotel_id(){ return hotel_id; };
    void set_hotel_id(std::string _hotel_id) { hotel_id = _hotel_id; };
};

#endif
