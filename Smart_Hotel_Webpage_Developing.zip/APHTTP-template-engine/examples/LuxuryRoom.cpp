
#include "LuxuryRoom.h"

LuxuryRoom::LuxuryRoom(std::string _room_id, int _room_price)
{
    room_id = _room_id;
    room_price = _room_price;
}

