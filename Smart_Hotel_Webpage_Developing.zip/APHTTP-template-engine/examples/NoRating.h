
#ifndef A7_NORATING_H
#define A7_NORATING_H

#include <exception>

class NotRating : public std::exception {
    virtual const char* what() const throw()
    {
        return "Not Rating\n";
    }
};

#endif
