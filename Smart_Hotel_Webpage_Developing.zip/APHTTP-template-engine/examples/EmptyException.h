
#ifndef A7_EMPTYEXCEPTION_H
#define A7_EMPTYEXCEPTION_H

#include <exception>

class EmptyException: public std::exception{
    virtual const char* what() const throw()
    {
        return "Empty\n";
    }
};

#endif
