
#ifndef A7_PRICERANGEFILTER_H
#define A7_PRICERANGEFILTER_H

#include "Filter.h"

class PriceRangeFilter:public Filter{
private:
    double min_price;
    double max_price;
public:
    PriceRangeFilter(double _min_price, double _max_price);
    std::vector<Hotel *> apply_filter(std::vector<Hotel *> _all_hotels) override;
};

#endif
