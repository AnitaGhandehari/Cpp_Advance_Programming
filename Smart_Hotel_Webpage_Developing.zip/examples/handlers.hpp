#ifndef _MY_HANDLERS_
#define _MY_HANDLERS_

#include "../server/server.hpp"
#include <cstdlib> // for rand and srand
#include <ctime>   // for time
#include <iostream>
#include "MainServer.h"

class RandomNumberHandler : public RequestHandler {
private:
    MainServer *server_manager;
public:
    RandomNumberHandler(MainServer* _server);
    Response *callback(Request *);
};

class LoginHandler : public RequestHandler {
private:
    MainServer *server_manager;
public:
    LoginHandler(MainServer* _server);
    Response *callback(Request *);
};

class SignupHandler : public RequestHandler {
private:
    MainServer *server_manager;
public:
    SignupHandler(MainServer* _server);
    Response *callback(Request *);
};


class HomePageHandler : public RequestHandler {
private:
    MainServer *server_manager;
public:
    HomePageHandler(MainServer* _server);
    Response *callback(Request *);
};


class WalletHandler : public RequestHandler {
private:
    MainServer *server_manager;
public:
    WalletHandler(MainServer* _server);
    Response *callback(Request *);
};
class UpdateCredit : public RequestHandler {
private:
    MainServer *server_manager;
public:
    UpdateCredit(MainServer* _server){server_manager = _server;};
    Response *callback(Request *) ;
};

class FilterHandler : public RequestHandler {
private:
    MainServer *server_manager;
public:
    FilterHandler(MainServer* _server){server_manager = _server;};
    Response *callback(Request *) ;
};


class FilterPage : public RequestHandler {
private:
    MainServer *server_manager;
public:
    FilterPage(MainServer* _server){server_manager = _server;};
    Response *callback(Request *) ;
};

class DetailHandler : public RequestHandler {
private:
MainServer *server_manager;
public:
    DetailHandler(MainServer* _server){server_manager = _server;};
    Response *callback(Request *) ;
};

class LogoutlHandler : public RequestHandler {
private:
MainServer *server_manager;
public:
    LogoutlHandler(MainServer* _server){server_manager = _server;};
    Response *callback(Request *) ;
};



#endif
