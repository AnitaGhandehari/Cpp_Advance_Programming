#include "my_server.hpp"

MyServer::MyServer(int port) : Server(port) {}
