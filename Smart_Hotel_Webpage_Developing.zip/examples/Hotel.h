
#ifndef A7_HOTEL_H
#define A7_HOTEL_H

#include <string>
#include <vector>
#include <iostream>
#include <iomanip>
#include <algorithm>
#include <cstdint>


#include "Room.h"
#include "StandardRoom.h"
#include "DeluxRoom.h"
#include "LuxuryRoom.h"
#include "PremiumRoom.h"
#include "Comment.h"
#include "Rating.h"
#include "NoRating.h"

struct weights{
    double location;
    double cleanliness;
    double staff;
    double facilities;
    double value_for_money;
};

class Hotel{
public:
    std::string unique_id;
    std::string property_name;
    int hotel_star_rating;
    std::string hotel_overview;
    std::vector<std::string> property_amenities;
    std::string city;
    double latitude;
    double longitude;
    std::string image_url;
    std::vector<Room*> hotel_rooms;
    int standard_room_num = 0;
    int deluxe_room_num = 0;
    int luxury_room_num = 0;
    int premium_room_num = 0;
    int standard_room_price = 0;
    int deluxe_room_price = 0;
    int luxury_room_price = 0;
    int premium_room_price = 0;
    std::vector<Comment*> hotel_comments;
    Rating* hotel_rating = nullptr;
    double personal_rating = 0;

public:

    void set_unique_id(const std::string& _unique_id){unique_id = _unique_id;};
    void set_property_name(const std::string& _property_name){property_name = _property_name;};
    void set_hotel_star_rating(const int& _hotel_star_rating){hotel_star_rating = _hotel_star_rating;};
    void set_hotel_overview(const std::string& _hotel_overview){hotel_overview = _hotel_overview;};
    void set_property_amenities(const std::vector<std::string>& _property_amenities){property_amenities = _property_amenities;};
    void set_city(const std::string& _city){city = _city;};
    void set_latitude(double _latitude){latitude = _latitude;};
    void set_longitude(double _longitude){longitude = _longitude;};
    void set_image_url(const std::string& _image_url){image_url = _image_url;};
    void set_hotel_rooms(std::vector<std::string> _all_hotel_info);
    std::string get_unique_id(){ return unique_id; };
    std::string get_name(){ return property_name; };
    std::string get_city(){ return city; };
    std::string get_url(){ return image_url; };
    int get_standard_room_price() { return standard_room_price; };
    int get_deluxe_room_price() { return deluxe_room_price; };
    int get_luxury_room_price() { return luxury_room_price; };
    int get_premium_room_price() { return premium_room_price; };
    double get_rating_overall() { return hotel_rating->get_overall_rating(); };
    double get_personal_rating() { return  personal_rating; };
    int get_star() { return hotel_star_rating; };
    double get_average_room_price();
    void print_hotel_summary();
    void print_total_hotel_info();
    bool check_city(std::string _city);
    bool check_hotel_star_range(int _min, int _max);
    bool check_hotel_price_range(double _min_price, double _max_price);
    std::vector<Room*> manage_hotel_reserve(std::string _type, int _quantity, int _check_in, int _check_out);
    void add_comment(std::string user_name, std::string _comment);
    void print_comments();
    void add_rating(double _location, double _cleanliness, double _staff, double _facilities, double _value_money, double _overall_rating);
    void calculate_average_rating();
    void set_personal_rating_value(std::vector<Rating*> _user_ratings, weights _user_weights);

};

#endif
