#include "handlers.hpp"
#include "my_server.hpp"
#include <cstdlib> // for rand and srand
#include <ctime>   // for time
#include <iostream>
#include "MainServer.h"
#include <exception>
using namespace std;

int main(int argc, char **argv) {
  srand(time(NULL)); // for rand
  auto *manager_server = new MainServer();
  try {
      manager_server->read_hotel_files(argv);
      cout << "DONE1" << endl;
      manager_server->read_ratings_file(argv);
      cout << "DONE2" << endl;
    MyServer server(argc > 1 ? atoi(argv[1]) : 5000);
    server.setNotFoundErrPage("static/404.html");
    server.get("/login", new ShowPage("static/login.html"));
    server.post("/login", new LoginHandler(manager_server));
    server.get("/signup", new ShowPage("static/signup.html"));
    server.get("/main", new HomePageHandler(manager_server));
    server.post("/signup", new SignupHandler(manager_server));
    server.get("/rand", new RandomNumberHandler(manager_server));
    server.get("/wallet", new WalletHandler(manager_server));
    server.post("/credit", new UpdateCredit(manager_server));
    server.post("/filter", new FilterHandler(manager_server));
    server.get("/filter_page", new FilterPage(manager_server));
    server.get("/home.png", new ShowImage("static/home.png"));
    server.get("/", new ShowPage("static/home.html"));
      server.post("/logout", new LogoutlHandler(manager_server));
    server.get("/detail", new DetailHandler(manager_server));

    server.run();
  } catch (Server::Exception e) {
    cerr << e.getMessage() << endl;
  }
}
