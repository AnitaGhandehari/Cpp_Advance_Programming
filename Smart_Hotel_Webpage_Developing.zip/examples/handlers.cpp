#include "handlers.hpp"
#include <fstream>
using namespace std;


Response *RandomNumberHandler::callback(Request *req) {
  Response *res = new Response;
  res->setHeader("Content-Type", "text/html");
  string body;
  body += "<!DOCTYPE html>";
  body += "<html>";
  body += "<body style=\"text-align: center;\">";
  body += "<h1>AP HTTP</h1>";
  body += "<p>";
  body += "a random number in [1, 10] is: ";
  body += to_string(rand() % 10 + 1);
  body += "</p>";
  body += "<p>";
  body += "SeddionId: ";
  body += req->getSessionId();
  body += "</p>";
  body += "</body>";
  body += "</html>";
  res->setBody(body);
  return res;
}

Response *LoginHandler::callback(Request *req) {
  hash <string> hash;
  string email = req->getBodyParam("email");
  string password = req->getBodyParam("password");
  unsigned long hashed_password = hash(password);
  if (email == "root")
    throw Server::Exception("Remote root access has been disabled.");
  try {
      server_manager->login(email, hashed_password);
  }catch(...)
  {
      throw Server::Exception("Remote root access has been disabled.");
  }
  cout << "username: " << email << ",\tpassword: " << password << endl;
  Response *res = Response::redirect("/rand");
  res->setSessionId("SID");
  return res;
}

Response *SignupHandler::callback(Request *req) {
    hash <string> hash;
    string email = req->getBodyParam("email");
    string password = req->getBodyParam("password");
    string username =  req->getBodyParam("username");
    unsigned long hashed_password = hash(password);
    if (email == "root")
        throw Server::Exception("Remote root access has been disabled.");
    try {
        server_manager->signup(email, username, hashed_password);
    }catch(...)
    {
        throw Server::Exception("Remote root access has been disabled.");
    }
    cout << "username: " << email << ",\tpassword: " << password << endl;
    Response *res = Response::redirect("/main");
    //res->setSessionId("SID");
    return res;
}

Response *HomePageHandler::callback(Request *req) {

    Response *res = new Response;
    res->setHeader("Content-Type", "text/html");
    try {
        server_manager->get_hotels();
    }catch(...)
    {
        throw Server::Exception("Remote root access has been disabled.");
    }
    ostringstream body;
        body
            << "<html>" << endl
            << "    <head><title>HOME</title>" << endl
            << "    </head>" << endl
            << "    <body>" << endl
            << "<form action=\"/filter\" method=post>" << endl
            << "Low: <input type=\"text\" name=\"low\"><br/>" << endl
            << "High: <input type=\"text\" name=\"high\"><br/>" << endl
            << " <input type=\"submit\" value=\"Filter\"/> " << endl
            << "     </form>" << endl
            << "   <form method=\"get\" action=\"/wallet\">" << endl
            << "                             <button type=\"submit\">Wallet</button>" << endl
            << "                                         </form>" << endl
            << "   <form method=\"post\" action=\"/logout\">" << endl
            << "                             <button type=\"submit\">Logout</button>" << endl
            << "                                         </form>" << endl
            << "            <table border=1>" << endl
            << "                <tr>" << endl
            << "                    <th>Name</th>" << endl
            << "                    <th>Rating</th>" << endl
            << "                    <th>City</th>" << endl
            << "                    <th>Pic</th>" << endl
            << "                    <th>Details</th>" << endl
            << "                    <th>&nbsp;</th>" << endl
            << "                </tr>" << endl;
    for(int i = 0 ; i < server_manager->hotels_table.size() ; i++)
    {
        body
                << "                    <tr>" << endl
                << "                        <td>" << server_manager->hotels_table[i]->get_name() << "</td>"
                << endl
                << "                        <td>" << server_manager->hotels_table[i]->get_star() << "</td>"
                << endl
                << "                        <td>" << server_manager->hotels_table[i]->get_city() << endl
                << "                        <td>" << "<img src=" << server_manager->hotels_table[i]->get_url()
                << "></img>" << "</td>" << endl
                << "<td> <form method=\"get\" action=\"/detail\">" << endl
                << "<input style=\"display:none;\" name=id type=\"text\"  value =" << server_manager->filtered_hotels_table[i]->get_unique_id() << "><br/>" << endl
                << "\"<button type=\"submit\">Details</button></td>\"" << endl
                << "</form>"
                << "                    </tr>" << endl;
    }

        body
            << "            </table>" << endl
            << "    </body>" << endl
            << "</html>" << endl;
    res->setBody(body.str());
    return res;
}

Response * WalletHandler::callback(Request *req)
{
    Response *res = new Response;
    int increase;

    res->setHeader("Content-Type", "text/html");
    ostringstream body;
        body
            << "<html>" << endl
            << "    <head><title>Wallet</title>" << endl
            << "    </head>" << endl
            << "    <body>" << endl
            << "    <p>" << endl
            << "      Credit: " << endl
            << server_manager->logged_in_user->get_credit()<< endl
            << "    </p>" << endl
            << "<form action=\"/credit\" method=post>" << endl
            << "Increase Credit: <input type=\"text\" name=\"increase\"><br/>" << endl;
          body  << " <input type=\"submit\" value=\"Save\"/> " << endl
            << "     </form>" << endl;

    body << "    </body>" << endl
            << "</html>" << endl;
    res->setBody(body.str());
    return res;
}

Response * UpdateCredit::callback(Request *req)
{
    server_manager->increase_credit(stoi(req->getBodyParam("increase")));
    return Response::redirect("/wallet");
}

Response * FilterPage::callback(Request *req)
{
    Response *res = new Response;
    res->setHeader("Content-Type", "text/html");
    try {
        server_manager->get_hotels();
    }catch(...)
    {
        throw Server::Exception("Remote root access has been disabled.");
    }
    ostringstream body;
    body
            << "<html>" << endl
            << "    <head><title>HOME</title>" << endl
            << "    </head>" << endl
            << "    <body>" << endl
            << "            <table border=1>" << endl
            << "                <tr>" << endl
            << "                    <th>Name</th>" << endl
            << "                    <th>Rating</th>" << endl
            << "                    <th>City</th>" << endl
            << "                    <th>Pic</th>" << endl
            << "                    <th>Details</th>" << endl
            << "                    <th>&nbsp;</th>" << endl
            << "                </tr>" << endl;

    for(int i = 0 ; i < server_manager->filtered_hotels_table.size() ; i++)
    {
        body
                << "                    <tr>" << endl
                << "                        <td>" << server_manager->filtered_hotels_table[i]->get_name() << "</td>"
                << endl
                << "                        <td>" << server_manager->filtered_hotels_table[i]->get_star() << "</td>"
                << endl
                << "                        <td>" << server_manager->filtered_hotels_table[i]->get_city() << endl
                << "                        <td>" << "<img src=" << server_manager->filtered_hotels_table[i]->get_url()
                << "></img>" << "</td>" << endl
                << "<td> <form method=\"get\" action=\"/detail\">" << endl
                << "<input style=\"display:none;\" name=\"id\" type=\"text\"  value =" << server_manager->filtered_hotels_table[i]->get_unique_id() << "><br/>" << endl
                << "\"<button type=\"submit\">Details</button></td>\"" << endl
                << "</form>"
                << "                    </tr>" << endl;
    }

    body
            << "            </table>" << endl
            << "    </body>" << endl
            << "</html>" << endl;
    res->setBody(body.str());
    return res;
}

Response * FilterHandler::callback(Request *req)
{
    server_manager->filter_by_star(stod(req->getBodyParam("low")), stod(req->getBodyParam("high")));
    server_manager->apply_filters();
    server_manager->get_hotels();
    cout << server_manager->filtered_hotels_table.size() << endl;
    return Response::redirect("/filter_page");
}

Response * LogoutlHandler::callback(Request *req)
{
    server_manager->logout();
    return Response::redirect("/");
}

Response * DetailHandler::callback(Request *req)
{

    Response *res = new Response;
    res->setHeader("Content-Type", "text/html");
    int int_id;
    string id = req->getBodyParam("id");
    cout << id << endl;
    try {
        for(int i = 0; i < server_manager->hotels_table.size() ; i++)
            if(server_manager->hotels_table[i]->get_unique_id() == id) {
                int_id = i;
                cout<< "HELLLOOOOOO = " << int_id << endl;
            }
    }catch(...)
    {
        throw Server::Exception("Remote root access has been disabled.");
    }
    ostringstream body;
    body
            << "<html>" << endl
            << "    <head><title>Detail</title>" << endl
            << "    </head>" << endl
            << "    <body>" << endl
            << "                        <p>" << "<img src=" << server_manager->filtered_hotels_table[int_id]->get_url()
            << "></img>" << "/<p>" << endl
            << "    <p>" << endl
            << "      Name:  " << server_manager->hotels_table[int_id]->get_name() << endl
            << "    </p>" << endl
            << "    <p>" << endl
            << "      hotel overview:  " << server_manager->hotels_table[int_id]->hotel_overview << endl
            << "    </p>" << endl
            << "    <p>" << endl
            << "      property amenities:  " << endl
            << "    </p>" << endl;
    for(int j = 0 ; j < server_manager->hotels_table[int_id]->property_amenities.size() ; j++)
    {
        body   << "    <p>" << endl
        << server_manager->hotels_table[int_id]->property_amenities[j] << endl
        << "    </p>" << endl;
    }
     body   << "    <p>" << endl
            << "     Rating:  " << server_manager->hotels_table[int_id]->get_rating_overall() << endl
            << "    </p>" << endl
             << "    <p>" << endl
             << "     City:  " << server_manager->hotels_table[int_id]->get_city() << endl
             << "    </p>" << endl
            << "            <table border=1>" << endl
            << "                <tr>" << endl
            << "                    <th>standard</th>" << endl
            << "                    <th>luxury</th>" << endl
            << "                    <th>deluxe</th>" << endl
            << "                    <th>premium</th>" << endl
            << "                    <th>&nbsp;</th>" << endl
            << "                </tr>" << endl;

    body
            << "                    <tr>" << endl
            << "                        <td>" << server_manager->hotels_table[int_id]->standard_room_num << "</td>" << endl
            << "                        <td>" << server_manager->hotels_table[int_id]->luxury_room_num << "</td>" << endl
            << "                        <td>" << server_manager->hotels_table[int_id]->deluxe_room_num << "</td>" << endl
            << "                        <td>" << server_manager->hotels_table[int_id]->premium_room_num << "</td>" << endl
            << "                    </tr>" << endl;
        body
                << "                    <tr>" << endl
                << "                        <td>" << server_manager->hotels_table[int_id]->get_standard_room_price() << "</td>" << endl
                << "                        <td>" << server_manager->hotels_table[int_id]->get_luxury_room_price() << "</td>" << endl
                << "                        <td>" << server_manager->hotels_table[int_id]->get_deluxe_room_price() << "</td>" << endl
                << "                        <td>" << server_manager->hotels_table[int_id]->get_premium_room_price() << "</td>" << endl
                << "                    </tr>" << endl;


    body
            << "            </table>" << endl
            << "    </body>" << endl
            << "</html>" << endl;
    res->setBody(body.str());
    return res;
}

RandomNumberHandler::RandomNumberHandler(MainServer *_server)
{
    server_manager = _server;
}

LoginHandler::LoginHandler(MainServer *_server)
{
    server_manager = _server;
}

SignupHandler::SignupHandler(MainServer *_server)
{
    server_manager = _server;
}

HomePageHandler::HomePageHandler(MainServer *_server)
{
    server_manager = _server;
}

WalletHandler::WalletHandler(MainServer *_server)
{
    server_manager = _server;
}