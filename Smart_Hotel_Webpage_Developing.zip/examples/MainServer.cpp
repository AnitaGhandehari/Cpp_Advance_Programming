
#include "MainServer.h"

using namespace std;

bool compare_id(Hotel* a, Hotel* b)
{
    int size = 0;
    if(a->get_unique_id().size() < b->get_unique_id().size())
        size = a->get_unique_id().size();
    else
        size = b->get_unique_id().size();

    for(int i = 0 ; i < size ; i++)
    {
        if (a->get_unique_id()[i] == b->get_unique_id()[i])
            continue;
        else
            return (a->get_unique_id()[i] < b->get_unique_id()[i]);
    }
}

bool compare_name(Hotel* a, Hotel* b)
{
    int size = 0;
    if(a->get_name().size() < b->get_name().size())
        size = a->get_name().size();
    else
        size = b->get_name().size();

    for(int i = 0 ; i < size ; i++)
    {
        if (a->get_name()[i] == b->get_name()[i])
            continue;
        else
            return (a->get_name()[i] < b->get_name()[i]);
    }
    return compare_id(a, b);
}

bool compare_city(Hotel* a, Hotel* b)
{
    int size = 0;
    if(a->get_city().size() < b->get_city().size())
        size = a->get_city().size();
    else
        size = b->get_city().size();

    for(int i = 0 ; i < size ; i++)
    {
        if (a->get_city()[i] == b->get_city()[i])
            continue;
        else
            return (a->get_city()[i] < b->get_city()[i]);
    }
    return compare_id(a, b);
}

bool compare_standard_price(Hotel* a, Hotel* b)
{
    if(a->get_standard_room_price() == b->get_standard_room_price())
        return compare_id(a, b);
    return (a->get_standard_room_price() < b->get_standard_room_price());
}

bool compare_deluxe_price(Hotel* a, Hotel* b)
{
    if(a->get_deluxe_room_price() == b->get_deluxe_room_price())
        return compare_id(a, b);
    return (a->get_deluxe_room_price() < b->get_deluxe_room_price());
}

bool compare_luxury_price(Hotel* a, Hotel* b)
{
    if(a->get_luxury_room_price() == b->get_luxury_room_price())
        return compare_id(a, b);
    return (a->get_luxury_room_price() < b->get_luxury_room_price());
}

bool compare_premium_price(Hotel* a, Hotel* b)
{
    if(a->get_premium_room_price() == b->get_premium_room_price())
        return compare_id(a, b);
    return (a->get_premium_room_price() < b->get_premium_room_price());
}

bool compare_average_price(Hotel* a, Hotel* b)
{
    if(a->get_average_room_price() == b->get_average_room_price())
        return compare_id(a, b);
    return (a->get_average_room_price() < b->get_average_room_price());
}

bool compare_star(Hotel* a, Hotel* b)
{
    if(a->get_star() == b->get_star())
        return compare_id(a, b);
    return (a->get_star() < b->get_star());
}

bool compare_overall_rating(Hotel* a, Hotel* b)
{
    if(a->get_rating_overall() == b->get_rating_overall())
        return compare_id(a, b);
    return (a->get_rating_overall() < b->get_rating_overall());
}

bool compare_personal_rating(Hotel* a, Hotel* b)
{
    if(a->get_personal_rating() == b->get_personal_rating())
        return compare_id(a, b);
    return (a->get_personal_rating() < b->get_personal_rating());
}

std::vector<std::string> MainServer::prepare_property_vector(std::string _property_amenities)
{
    string word;
    vector<string> all_hotel_property;

    stringstream property_info(_property_amenities);
    while (getline(property_info, word, PROPERTY_SEPARATOR))
    {
        all_hotel_property.push_back(word);
    }
    return all_hotel_property;
}

Hotel* MainServer::classify_each_hotel_info(std::vector<std::string> _all_hotel_info)
{
    Hotel* each_hotel_classified_info = new Hotel();
    each_hotel_classified_info->set_unique_id(_all_hotel_info[0]);
    each_hotel_classified_info->set_property_name(_all_hotel_info[1]);
    each_hotel_classified_info->set_hotel_star_rating(stoi(_all_hotel_info[2]));
    each_hotel_classified_info->set_hotel_overview(_all_hotel_info[3]);
    each_hotel_classified_info->set_property_amenities(prepare_property_vector(_all_hotel_info[4]));
    each_hotel_classified_info->set_city(_all_hotel_info[5]);
    each_hotel_classified_info->set_latitude(stod(_all_hotel_info[6]));
    each_hotel_classified_info->set_longitude(stod(_all_hotel_info[7]));
    each_hotel_classified_info->set_image_url(_all_hotel_info[8]);
    each_hotel_classified_info->set_hotel_rooms(_all_hotel_info);
    return each_hotel_classified_info;
}

Rating* MainServer::classify_each_rating_info(std::vector<std::string> _all_rating_info)
{
    string id;
    double location;
    double cleanliness;
    double staff;
    double facilities;
    double value_for_money;
    double overall_rating;
    id = _all_rating_info[0];
    location = stod(_all_rating_info[1]);
    cleanliness = stod(_all_rating_info[2]);
    staff = stod(_all_rating_info[3]);
    facilities = stod(_all_rating_info[4]);
    value_for_money = stod(_all_rating_info[5]);
    overall_rating = stod(_all_rating_info[6]);

    add_rating_for_hotel(id, location, cleanliness, staff, facilities, value_for_money, overall_rating);
}

void MainServer::read_hotel_files(char **argv)
{
    string file_address;
    vector<string> all_hotel_info;
    string line;
    string word;

    file_address = "hotels.csv";

    ifstream hotels_file(file_address);
    if(hotels_file.fail())
    {
        cout << "Hotel File Does not Open" << endl;
        exit(1);
    }
    getline(hotels_file, line);
    while (getline(hotels_file, line))
    {
        stringstream hotel_info(line);
        while (getline(hotel_info, word, EVERY_PART_SEPARATOR))
        {
            all_hotel_info.push_back(word);
        }
        hotels_table.push_back(classify_each_hotel_info(all_hotel_info));
        all_hotel_info.clear();
    }
    sort_by_id();
}

void MainServer::read_ratings_file(char **argv)
{
    string file_address;
    vector<string> all_rating_info;
    string line;
    string word;

    file_address = "ratings.csv";
    ifstream rating_file(file_address);
    if(rating_file.fail())
    {
        cout << "Rating File Does not Open" << endl;
        exit(1);
    }
    getline(rating_file, line);
    while (getline(rating_file, line))
    {
        stringstream hotel_info(line);
        while (getline(hotel_info, word, EVERY_PART_SEPARATOR))
        {
            all_rating_info.push_back(word);
        }
        classify_each_rating_info(all_rating_info);
        all_rating_info.clear();
    }
}

void MainServer::signup(std::string _email, std::string _user_name, unsigned long _password)
{
    if(all_users.empty())
    {
        for (int each_user = 0; each_user < all_users.size(); each_user++)
        {
            if (all_users[each_user]->get_user_name() == _user_name || all_users[each_user]->get_email() == _email)
                throw BadRequestException();
        }
    }

    User *user1 = new User(_email, _user_name, _password);
    logged_in_user = user1;
    login_flag = true;
    all_users.push_back(user1);
    cout << "OK" << endl;
}

void MainServer::login(std::string _email, unsigned long _password)
{
    if(all_users.empty())
    {
        for (int each_user = 0; each_user < all_users.size(); each_user++)
        {
            if (all_users[each_user]->check_login(_email, _password)) {
                logged_in_user = all_users[each_user];
                login_flag = true;
            }
        }
    }
    if(!login_flag)
        throw BadRequestException();
    else{
        cout << "OK" << endl;
    }
}

void MainServer::logout()
{
    if(login_flag)
    {
        login_flag = false;
        logged_in_user = nullptr;
        all_filters.clear();
        cout << "OK" << endl;
    }
    else
        throw PermissionDeniedException();
}

void MainServer::increase_credit(double _amount)
{
    if(_amount < 0)
        throw BadRequestException();
    if(!login_flag)
        throw PermissionDeniedException();

    logged_in_user->increase_user_credit(_amount);
    cout << "OK" << endl;
}

void MainServer::get_wallet_turnover(int _count)
{
    logged_in_user->print_wallet_turnover(_count);
}

void MainServer::get_hotels()
{
    filtered_hotels_table = hotels_table;
    filtered_by_budget();
    apply_filters();
    if(budget_flag)
        cout << "* Results have been filtered by the default price filter." << endl;
    if(!login_flag)
        throw PermissionDeniedException();
    if(filtered_hotels_table.empty())
        throw EmptyException();
    cout << "hotel_num" << filtered_hotels_table.size() << endl;
    for(auto & hotel_num : filtered_hotels_table)
        hotel_num->print_hotel_summary();
}

void MainServer::print_each_hotel_info(std::string _unique_id)
{
    if(!login_flag)
        throw PermissionDeniedException();
    bool hotel_exist = false;
    for(int each_hotel = 0 ; each_hotel < hotels_table.size() ; each_hotel++)
    {
        if(hotels_table[each_hotel]->get_unique_id() == _unique_id)
        {
            hotels_table[each_hotel]->print_total_hotel_info();
            hotel_exist = true;
        }
    }
    if(!hotel_exist)
        throw NotFoundException();
}

void MainServer::reserve_room(std::string _hotel_id, std::string _type, int _quantity, int _check_in, int _check_out)
{
    Hotel *hotel_for_reserve = nullptr;
    vector<Room*> reserved_room;
    bool hotel_exist = false;
    double price = 0;
    for(int each_hotel = 0 ; each_hotel < hotels_table.size() ; each_hotel++)
    {
        if(hotels_table[each_hotel]->get_unique_id() == _hotel_id)
        {
            hotel_for_reserve = hotels_table[each_hotel];
            hotel_exist = true;
        }
    }
    if(!hotel_exist)
        throw NotFoundException();
    reserved_room = hotel_for_reserve->manage_hotel_reserve(_type, _quantity, _check_in, _check_out);

    if(reserved_room.size() == _quantity)
    {
        price = double(reserved_room[0]->get_room_price() * reserved_room.size());
        if (price > logged_in_user->get_credit())
            throw NotEnoughCredit();
        for(int each_room = 0 ; each_room < reserved_room.size() ; each_room++)
        {
            reserved_room[each_room]->add_reserve_time(_check_in, _check_out);
            reserved_room[each_room]->print_id();
        }
        logged_in_user->add_reserve(_check_in, _check_out, _type, reserved_room, hotel_for_reserve);
        logged_in_user->decrease_reserve_credit(price);
        cout << endl;
    }
    else
        throw NotEnoughRoom();

}

void MainServer::print_user_reservation()
{
    logged_in_user->print_reservation();
}

void MainServer::cancel_reservation(int _id)
{
    logged_in_user->cancel_user_reserve(_id);
    cout << "OK" << endl;
}

void MainServer::add_comment_for_hotel(std::string _id, std::string _comment)
{
    bool hotel_exist = false;
    for(int each_hotel = 0 ; each_hotel < hotels_table.size() ; each_hotel++)
    {
        if(hotels_table[each_hotel]->get_unique_id() == _id)
        {
            hotel_exist = true;
            hotels_table[each_hotel]->add_comment(logged_in_user->get_user_name(), _comment);
        }
    }
    if(!hotel_exist)
        throw NotFoundException();
    cout << "OK" << endl;
}

void MainServer::print_comments_of_hotel(std::string _id)
{
    bool hotel_exist = false;
    for(int each_hotel = 0 ; each_hotel < hotels_table.size() ; each_hotel++)
    {
        if(hotels_table[each_hotel]->get_unique_id() == _id)
        {
            hotels_table[each_hotel]->print_comments();
            hotel_exist = true;
        }
    }
    if(!hotel_exist)
        throw NotFoundException();
}

void MainServer::add_rating_for_hotel(std::string _id, double _location, double _cleanliness, double _staff, double _facilities, double _value_money, double _overall_rating)
{
    for(int each_hotel = 0 ; each_hotel < hotels_table.size() ; each_hotel++)
    {
        if (hotels_table[each_hotel]->get_unique_id() == _id)
            hotels_table[each_hotel]->add_rating(_location, _cleanliness, _staff, _facilities, _value_money, _overall_rating);
    }
}

void MainServer::add_rating_for_user(std::string _id, double _location, double _cleanliness, double _staff, double _facilities, double _value_money, double _overall_rating)
{
    Rating* rating1 = new Rating(_location, _cleanliness, _staff, _facilities, _value_money, _overall_rating);
    rating1->set_hotel_id(_id);
    logged_in_user->add_rating(rating1);
}

void MainServer::print_average_rating(std::string _id)
{
    bool hotel_exist = false;
    for(auto & each_hotel : hotels_table)
    {
        if (each_hotel->get_unique_id() == _id)
        {
            each_hotel->calculate_average_rating();
            hotel_exist = true;
        }
    }
    if(!hotel_exist)
        throw NotFoundException();
}

void MainServer::apply_filters()
{
    for(int i = 0 ; i < all_filters.size() ; i++)
        filtered_hotels_table = all_filters[i]->apply_filter(filtered_hotels_table);
}

void MainServer::filter_by_city(std::string _city)
{
    bool filter_exist = false;
    for(int each_filter = 0 ; each_filter < all_filters.size() ; each_filter++)
    {
        if(all_filters[each_filter]->get_type() == "city")
        {
            filter_exist = true;
            all_filters.erase(all_filters.begin() + each_filter);
            CityFilter* city_filter1 = new CityFilter(_city);
            all_filters.push_back(city_filter1);
        }
    }
    if(!filter_exist)
    {
        CityFilter* city_filter1 = new CityFilter(_city);
        all_filters.push_back(city_filter1);
    }
    cout << "OK" << endl;
}

void MainServer::filter_by_price(double _min_price, double _max_price)
{
    bool filter_exist = false;
    for(int each_filter = 0 ; each_filter < all_filters.size() ; each_filter++)
    {
        if(all_filters[each_filter]->get_type() == "price_filter")
        {
            filter_exist = true;
            all_filters.erase(all_filters.begin() + each_filter);
            PriceRangeFilter* price_filter1 = new PriceRangeFilter(_min_price, _max_price);
            all_filters.push_back(price_filter1);
        }
    }
    if(!filter_exist)
    {
        PriceRangeFilter* price_filter1 = new PriceRangeFilter(_min_price, _max_price);
        all_filters.push_back(price_filter1);
    }
    cout << "OK" << endl;
}

void MainServer::filter_by_room(std::string type, int quantity, int check_in, int check_out)
{
    bool filter_exist = false;
    for(int each_filter = 0 ; each_filter < all_filters.size() ; each_filter++)
    {
        if(all_filters[each_filter]->get_type() == "room_filter")
        {
            filter_exist = true;
            all_filters.erase(all_filters.begin() + each_filter);
            RoomFilter* room_filter1 = new RoomFilter(type, quantity, check_in, check_out);
            all_filters.push_back(room_filter1);
        }
    }
    if(!filter_exist)
    {
        RoomFilter* room_filter1 = new RoomFilter(type, quantity, check_in, check_out);
        all_filters.push_back(room_filter1);
    }
    cout << "OK" << endl;
}

void MainServer::filter_by_star(double _min_star, double _max_star)
{
    bool filter_exist = false;
    for(int each_filter = 0 ; each_filter < all_filters.size() ; each_filter++)
    {
        if(all_filters[each_filter]->get_type() == "star_filter")
        {
            filter_exist = true;
            all_filters.erase(all_filters.begin() + each_filter);
            StarRangeFilter* star_filter1 = new StarRangeFilter(_min_star, _max_star);
            all_filters.push_back(star_filter1);
        }
    }
    if(!filter_exist)
    {
        StarRangeFilter* star_filter1 = new StarRangeFilter(_min_star, _max_star);
        all_filters.push_back(star_filter1);
    }
    cout << "OK" << endl;
}

void MainServer::filtered_by_budget()
{
    bool check_price_type = false;
    if(logged_in_user->get_user_reserves().size() < 10)
        budget_flag = false;
    for(int each_filter = 0 ; each_filter < all_filters.size() ; each_filter++)
    {
        if(all_filters[each_filter]->get_type() == "price_filter")
            check_price_type = true;
        if((!budget_flag || logged_in_user->get_user_reserves().size() < 10) && check_price_type)
        {
            all_filters.erase(all_filters.begin() + each_filter);
        }
    }
    if(budget_flag && logged_in_user->get_user_reserves().size() >= 10 && !check_price_type)
    {
        BudgetFilter* budget_filter1 = new BudgetFilter(logged_in_user->get_user_reserves());
        all_filters.push_back(budget_filter1);
    }
}

void MainServer::get_instructions()
{
    string instruction_line;
    string line;
    string word;
    vector<string> all_separated_instructions;

    while(cin >> instruction_line)
    {
        std::getline(cin, line);
        instruction_line += line;
        try
        {
            stringstream instructions(instruction_line);

            while (getline(instructions, word, SPACE))
            {
                all_separated_instructions.push_back(word);
            }
            if(all_separated_instructions[0] == "POST")
                instructions_for_post_info(all_separated_instructions);
            else if(all_separated_instructions[0] == "GET")
                instructions_for_get_info(all_separated_instructions);
            else if(all_separated_instructions[0] == "DELETE")
                instruction_for_delete_info(all_separated_instructions);
            else
                throw BadRequestException();
        }
        catch (exception &ex)
        {
            cout << ex.what();
        }
        all_separated_instructions.clear();
    }
}

void MainServer::instructions_for_post_info(vector<string> _separated_instructions)
{
    if(_separated_instructions[1] == "signup" && _separated_instructions[2] == "?")
        manage_signup_instruction(_separated_instructions);
    else if(_separated_instructions[1] == "login" && _separated_instructions[2] == "?")
        manage_login_instruction(_separated_instructions);
    else if(_separated_instructions[1] == "logout")
        logout();
    else if(_separated_instructions[1] == "wallet" && _separated_instructions[2] == "?")
        manage_wallet_instruction(_separated_instructions);
    else if(_separated_instructions[1] == "reserves" && _separated_instructions[2] == "?")
        manage_reservation_instruction(_separated_instructions);
    else if(_separated_instructions[1] == "comments" && _separated_instructions[2] == "?")
        manage_add_comment_instruction(_separated_instructions);
    else if(_separated_instructions[1] == "ratings" && _separated_instructions[2] == "?")
        manage_add_rating_instruction(_separated_instructions);
    else if(_separated_instructions[1] == "filters" && _separated_instructions[2] == "?")
        manage_add_filters(_separated_instructions);
    else if(_separated_instructions[1] == "default_price_filter" && _separated_instructions[2] == "?")
        manage_budget_filter_instruction(_separated_instructions);
    else if(_separated_instructions[1] == "sort" && _separated_instructions[2] == "?")
        manage_sort_instruction(_separated_instructions);
    else if(_separated_instructions[1] == "manual_weights" && _separated_instructions[2] == "?")
        manage_post_weights_instruction(_separated_instructions);
    else
        throw BadRequestException();
}

void MainServer::instructions_for_get_info(std::vector<std::string> _separated_instructions)
{
    if(_separated_instructions[1] == "wallet" && _separated_instructions[2] == "?")
        manage_count_instruction(_separated_instructions);
    else if(_separated_instructions[1] == "hotels" && _separated_instructions.size() > 2)
    {
        if (_separated_instructions[2] == "?")
            manage_one_hotel_info_instruction(_separated_instructions);
    }
    else if(_separated_instructions[1] == "hotels")
    {
        get_hotels();
    }
    else if(_separated_instructions[1] == "reserves")
        print_user_reservation();
    else if(_separated_instructions[1] == "comments" && _separated_instructions[2] == "?")
        manage_print_comment_instruction(_separated_instructions);
    else if(_separated_instructions[1] == "ratings" && _separated_instructions[2] == "?")
        manage_print_rating_instruction(_separated_instructions);
    else if(_separated_instructions[1] == "manual_weights")
        print_weights();
    else if(_separated_instructions[1] == "estimated_weights")
        print_estimated_weights();
    else
        throw BadRequestException();
}

void MainServer::instruction_for_delete_info(std::vector<std::string> _separated_instructions)
{
    if(_separated_instructions[1] == "reserves" && _separated_instructions[2] == "?")
        manage_cancel_reservation(_separated_instructions);
    else if(_separated_instructions[1] == "filters")
    {
        all_filters.clear();
        cout << "OK" << endl;
    }
    else
        throw BadRequestException();
}

void MainServer::manage_signup_instruction(vector<string> _separated_instructions)
{
    hash <string> hash;
    string email;
    string username;
    string password;
    for(int each_instruction = 3 ; each_instruction < (_separated_instructions.size() - 1) ; each_instruction = each_instruction + 2)
    {
        if(_separated_instructions[each_instruction] == "email")
            email = _separated_instructions[each_instruction + 1];
        else if(_separated_instructions[each_instruction] == "username")
            username = _separated_instructions[each_instruction + 1];
        else if(_separated_instructions[each_instruction] == "password")
            password = _separated_instructions[each_instruction + 1];
    }
    unsigned long hashed_password = hash(password);
    signup(email, username, hashed_password);
}

void MainServer::manage_login_instruction(vector<string> _separated_instructions)
{
    string email;
    string password;
    hash <string> hash;

    for(int each_instruction = 3 ; each_instruction < (_separated_instructions.size() - 1) ; each_instruction = each_instruction + 2)
    {
        if(_separated_instructions[each_instruction] == "email")
            email = _separated_instructions[each_instruction + 1];
        else if(_separated_instructions[each_instruction] == "password")
            password = _separated_instructions[each_instruction + 1];
    }
    unsigned long hashed_password = hash(password);
    login(email, hashed_password);
}

void MainServer::manage_wallet_instruction(std::vector<std::string> _separated_instructions)
{
    double amount = 0;
    if(_separated_instructions[3] == "amount")
        amount = stod(_separated_instructions[4]);
    increase_credit(amount);
}

void MainServer::manage_count_instruction(std::vector<std::string> _separated_instructions)
{
    int count = 0;
    if(_separated_instructions[3] == "count")
        count = stoi(_separated_instructions[4]);
    get_wallet_turnover(count);
}

void MainServer::manage_one_hotel_info_instruction(std::vector<std::string> _separated_instructions)
{
    string id;
    if(_separated_instructions[3] == "id")
        id = _separated_instructions[4];
    print_each_hotel_info(id);
}

void MainServer::manage_reservation_instruction(std::vector<std::string> _separated_instructions)
{
    string id;
    string type;
    int quantity;
    int check_in, check_out;
    int instruction_check = 0;
    for(int each_instruction = 3 ; each_instruction < (_separated_instructions.size() - 1) ; each_instruction = each_instruction + 2)
    {
        if(_separated_instructions[each_instruction] == "hotel")
        {
            id = _separated_instructions[each_instruction + 1];
            instruction_check++;
        }
        else if(_separated_instructions[each_instruction] == "type")
        {
            type = _separated_instructions[each_instruction + 1];
            instruction_check++;
        }
        else if(_separated_instructions[each_instruction] == "quantity")
        {
            quantity = stoi(_separated_instructions[each_instruction + 1]);
            instruction_check++;
        }
        else if(_separated_instructions[each_instruction] == "check_in")
        {
            check_in = stoi(_separated_instructions[each_instruction + 1]);
            instruction_check++;
        }
        else if(_separated_instructions[each_instruction] == "check_out")
        {
            check_out = stoi(_separated_instructions[each_instruction + 1]);
            instruction_check++;
        }

    }
    if(instruction_check != 5)
        throw BadRequestException();
    reserve_room(id, type, quantity, check_in, check_out);
}

void MainServer::manage_cancel_reservation(std::vector<std::string> _separated_instructions)
{
    int id = 0;
    if(_separated_instructions[3] == "id")
        id = stoi(_separated_instructions[4]);
    else
        throw BadRequestException();
    cancel_reservation(id);
}

void MainServer::manage_add_comment_instruction(std::vector<std::string> _separated_instructions)
{
    string id;
    string comment;
    int instruction_check = 0 ;
    for(int each_instruction = 3 ; each_instruction < (_separated_instructions.size() - 1) ; each_instruction = each_instruction + 2)
    {
        if(_separated_instructions[each_instruction] == "hotel")
        {
            id = _separated_instructions[each_instruction + 1];
            instruction_check++;
        }
        else if(_separated_instructions[each_instruction] == "comment")
        {
            comment = _separated_instructions[each_instruction + 1];
            instruction_check++;
        }
    }
    if(instruction_check != 2)
        throw BadRequestException();
    add_comment_for_hotel(id, comment);
}

void MainServer::manage_add_rating_instruction(std::vector<std::string> _separated_instructions)
{
    string id;
    double location = 0;
    double cleanliness = 0;
    double staff = 0;
    double facilities = 0;
    double value_for_money = 0;
    double overall_rating = 0;
    int instruction_check = 0;
    bool input_check = false;

    if(!login_flag)
        throw PermissionDeniedException();

    for(int each_instruction = 3 ; each_instruction < (_separated_instructions.size() - 1) ; each_instruction = each_instruction + 2)
    {
        if(_separated_instructions[each_instruction] == "hotel")
        {
            id = _separated_instructions[each_instruction + 1];
            instruction_check++;
        }
        else if(_separated_instructions[each_instruction] == "location")
        {
            location = stod(_separated_instructions[each_instruction + 1]);
            if(location < 1 || location > 5)
                input_check = true;
            instruction_check++;
        }
        else if(_separated_instructions[each_instruction] == "cleanliness")
        {
            cleanliness = stod(_separated_instructions[each_instruction + 1]);
            if(cleanliness < 1 || cleanliness > 5)
                input_check = true;
            instruction_check++;
        }
        else if(_separated_instructions[each_instruction] == "staff")
        {
            staff = stod(_separated_instructions[each_instruction + 1]);
            if(staff < 1 || staff > 5)
                input_check = true;
            instruction_check++;
        }
        else if(_separated_instructions[each_instruction] == "facilities")
        {
            facilities = stod(_separated_instructions[each_instruction + 1]);
            if(facilities < 1 || facilities > 5)
                input_check = true;
            instruction_check++;
        }
        else if (_separated_instructions[each_instruction] == "value_for_money")
        {
            value_for_money = stod(_separated_instructions[each_instruction + 1]);
            if(value_for_money < 1 || value_for_money > 5)
                input_check = true;
            instruction_check++;
        }
        else if(_separated_instructions[each_instruction] == "overall_rating")
        {
            overall_rating = stod(_separated_instructions[each_instruction + 1]);
            if(overall_rating < 1 || overall_rating > 5)
                input_check = true;
            instruction_check++;
        }
        else
            throw BadRequestException();
    }
    if(instruction_check != 7)
        throw BadRequestException();
    if(input_check)
        throw BadRequestException();
    add_rating_for_user(id, location, cleanliness, staff, facilities, value_for_money, overall_rating);
    cout << "OK" << endl;
}

void MainServer::manage_print_comment_instruction(std::vector<std::string> _separated_instructions)
{
    string id;
    if(_separated_instructions[3] == "hotel")
        id = _separated_instructions[4];
    else
        throw BadRequestException();
    print_comments_of_hotel(id);
}

void MainServer::manage_print_rating_instruction(std::vector<std::string> _separated_instructions)
{
    string id;
    if(_separated_instructions[3] == "hotel")
        id = _separated_instructions[4];
    else
        throw BadRequestException();
    print_average_rating(id);
}

void MainServer::manage_add_filters(std::vector<std::string> _separated_instructions)
{
    if(_separated_instructions[3] == "city")
        manage_city_filters_instruction(_separated_instructions);
    else if(_separated_instructions[3] == "min_star" || _separated_instructions[3] == "max_star")
        manage_star_filter_instruction(_separated_instructions);
    else if(_separated_instructions[3] == "min_price" || _separated_instructions[3] == "max_price")
        manage_price_filter_instruction(_separated_instructions);
    else if(_separated_instructions[3] == "type" || _separated_instructions[3] == "quantity" || _separated_instructions[3] == "check_in" || _separated_instructions[3] == "check_out")
        manage_room_filter_instruction(_separated_instructions);
}

void MainServer::manage_city_filters_instruction(std::vector<std::string> _separated_instructions)
{
    string city = "";
    for(int i = 4 ; i < _separated_instructions.size() ; i++)
        city += _separated_instructions[i];
    filter_by_city(city);
}

void MainServer::manage_star_filter_instruction(std::vector<std::string> _separated_instructions)
{
    double min_star = 0, max_star = 0;
    for(int each_instruction = 3 ; each_instruction < (_separated_instructions.size() - 1) ; each_instruction = each_instruction + 2)
    {
        if(_separated_instructions[each_instruction] == "min_star")
        {
            min_star = stod(_separated_instructions[each_instruction + 1]);
            if(min_star < 1 || min_star > 5)
                throw BadRequestException();
        }
        else if(_separated_instructions[each_instruction] == "max_star")
        {
            max_star = stod(_separated_instructions[each_instruction + 1]);
            if(max_star < 1 || max_star > 5)
                throw BadRequestException();
        }
    }
    if(max_star < min_star)
        throw BadRequestException();
    filter_by_star(min_star, max_star);
}

void MainServer::manage_price_filter_instruction(std::vector<std::string> _separated_instructions)
{
    double min_price = 0, max_price = 0;
    for(int each_instruction = 3 ; each_instruction < (_separated_instructions.size() - 1) ; each_instruction = each_instruction + 2)
    {
        if(_separated_instructions[each_instruction] == "min_price")
        {
            min_price = stod(_separated_instructions[each_instruction + 1]);
            if(min_price < 0)
                throw BadRequestException();
        }
        else if(_separated_instructions[each_instruction] == "max_price")
        {
            max_price = stod(_separated_instructions[each_instruction + 1]);
            if(max_price < 0)
                throw BadRequestException();
        }
    }
    if(max_price < min_price)
        throw BadRequestException();
    filter_by_price(min_price, max_price);
}

void MainServer::manage_room_filter_instruction(std::vector<std::string> _separated_instructions)
{
    std::string room_type;
    int quantity = 0;
    int check_in = 0;
    int check_out = 0;
    for(int each_instruction = 3 ; each_instruction < (_separated_instructions.size() - 1) ; each_instruction = each_instruction + 2)
    {
        if(_separated_instructions[each_instruction] == "type")
        {
            room_type = _separated_instructions[each_instruction + 1];
        }
        else if(_separated_instructions[each_instruction] == "quantity")
        {
            quantity = stoi(_separated_instructions[each_instruction + 1]);
        }
        else if(_separated_instructions[each_instruction] == "check_in")
        {
            check_in = stoi(_separated_instructions[each_instruction + 1]);
        }
        else if(_separated_instructions[each_instruction] == "check_out")
        {
            check_out = stoi(_separated_instructions[each_instruction + 1]);
        }
    }
    filter_by_room(room_type, quantity, check_in, check_out);
}

void MainServer::manage_budget_filter_instruction(std::vector<std::string> _separated_instructions)
{
    if(!login_flag)
        throw PermissionDeniedException();
    if(_separated_instructions[3] == "active")
    {
        if(_separated_instructions[4] == "true")
        {
            if (!budget_flag)
                budget_flag = true;
            cout << "OK" << endl;
        }
        else if(_separated_instructions[4] == "false")
        {
            cout << "OK" << endl;
            budget_flag = false;
        }
        else
            throw BadRequestException();
    }
    else
        throw BadRequestException();
}

void MainServer::manage_sort_instruction(std::vector<std::string> _separated_instructions)
{
    string property;
    if(!login_flag)
        throw PermissionDeniedException();
    for(int each_instruction = 3 ; each_instruction < (_separated_instructions.size() - 1) ; each_instruction = each_instruction + 2)
    {
        if (_separated_instructions[each_instruction] == "property")
            property = _separated_instructions[each_instruction + 1];

        else if (_separated_instructions[each_instruction] == "order")
        {
            if(_separated_instructions[each_instruction + 1] == "ascending")
                sort_order_flag = true;
            else if(_separated_instructions[each_instruction + 1] == "descending")
                sort_order_flag = false;
            else
                throw BadRequestException();
        }
        else
            throw BadRequestException();
    }
    manage_sort_property(property);
    cout << "OK" << endl;
}

void MainServer::manage_sort_property(const std::string& _property)
{
    if(_property == "id")
        sort_by_id();
    else if(_property == "name")
        sort_by_name();
    else if(_property == "city")
        sort_by_city();
    else if(_property == "standard_room_price")
        sort_by_standard_price();
    else if(_property == "deluxe_room_price")
        sort_by_deluxe_price();
    else if(_property == "luxury_room_price")
        sort_by_luxury_price();
    else if(_property == "premium_room_price")
        sort_by_premium_price();
    else if(_property == "average_room_price")
        sort_by_average_price();
    else if(_property == "star")
        sort_by_star();
    else if(_property == "rating_overall")
        sort_by_overall_rating();
    else if(_property == "rating_personal")
        sort_by_personal_rating();
    else
        throw BadRequestException();
}

void MainServer::manage_post_weights_instruction(std::vector<std::string> _separated_instructions)
{
    if(!login_flag)
        throw PermissionDeniedException();

    if (_separated_instructions[3] == "active")
    {
        if (_separated_instructions[4] == "true")
        {
            collect_weights(_separated_instructions);
            personal_rating = true;
        }
        else if (_separated_instructions[4] == "false")
            personal_rating = false;
        else
            throw BadRequestException();
    }
    else
        throw BadRequestException();
}

void MainServer::collect_weights(std::vector<std::string> _separated_instructions)
{
    weights input_weights{};
    int instruction_num = 0;

    for(int each_instruction = 3 ; each_instruction < (_separated_instructions.size() - 1) ; each_instruction = each_instruction + 2)
    {
        if (_separated_instructions[each_instruction] == "location")
        {
            input_weights.location = stod(_separated_instructions[each_instruction + 1]);
            instruction_num++;
            if(input_weights.location < 1 || input_weights.location > 5)
                throw BadRequestException();
        }
        else if (_separated_instructions[each_instruction] == "cleanliness")
        {
            input_weights.cleanliness = stod(_separated_instructions[each_instruction + 1]);
            instruction_num++;
            if(input_weights.cleanliness < 1 || input_weights.cleanliness > 5)
                throw BadRequestException();
        }
        else if (_separated_instructions[each_instruction] == "staff")
        {
            input_weights.staff = stod(_separated_instructions[each_instruction + 1]);
            instruction_num++;
            if(input_weights.staff < 1 || input_weights.staff > 5)
                throw BadRequestException();
        }
        else if (_separated_instructions[each_instruction] == "facilities")
        {
            input_weights.facilities = stod(_separated_instructions[each_instruction + 1]);
            instruction_num++;
            if(input_weights.facilities < 1 || input_weights.facilities > 5)
                throw BadRequestException();
        }
        else if (_separated_instructions[each_instruction] == "value_for_money")
        {
            input_weights.value_for_money = stod(_separated_instructions[each_instruction + 1]);
            instruction_num++;
            if(input_weights.value_for_money < 1 || input_weights.value_for_money > 5)
                throw BadRequestException();
        }
    }
    if(instruction_num != 5)
        throw BadRequestException();

    logged_in_user->set_user_weights(input_weights);
    for(auto & each_hotel : hotels_table)
        each_hotel->set_personal_rating_value(logged_in_user->get_user_ratings(), logged_in_user->get_user_weights());
    cout << "OK" << endl;
}

void MainServer::calculate_weights()
{
    logged_in_user->calculate_weights();
    for(auto & each_hotel : hotels_table)
        each_hotel->set_personal_rating_value(logged_in_user->get_user_ratings(), logged_in_user->get_user_weights());
}

void MainServer::print_weights()
{
    if(personal_rating)
        logged_in_user->print_user_weight();
    else
        cout << "active" << SPACE << "false" << endl;
}

void MainServer::print_estimated_weights()
{
    if(!login_flag)
        throw PermissionDeniedException();
    if(personal_rating)
    {
        logged_in_user->calculate_weights();
        logged_in_user->print_user_weight();
    }
}

void MainServer::sort_by_id()
{
    sort(hotels_table.begin(), hotels_table.end(), compare_id);
    if(!sort_order_flag)
        reverse(hotels_table.begin(), hotels_table.end());
}

void MainServer::sort_by_name()
{
    sort(hotels_table.begin(), hotels_table.end(), compare_name);
    if(!sort_order_flag)
        reverse(hotels_table.begin(), hotels_table.end());
}

void MainServer::sort_by_city()
{
    sort(hotels_table.begin(), hotels_table.end(), compare_city);
    if(!sort_order_flag)
        reverse(hotels_table.begin(), hotels_table.end());
}

void MainServer::sort_by_standard_price()
{
    sort(hotels_table.begin(), hotels_table.end(), compare_standard_price);
    if(!sort_order_flag)
        reverse(hotels_table.begin(), hotels_table.end());
}

void MainServer::sort_by_deluxe_price()
{
    sort(hotels_table.begin(), hotels_table.end(), compare_deluxe_price);
    if(!sort_order_flag)
        reverse(hotels_table.begin(), hotels_table.end());
}

void MainServer::sort_by_luxury_price()
{
    sort(hotels_table.begin(), hotels_table.end(), compare_luxury_price);
    if(!sort_order_flag)
        reverse(hotels_table.begin(), hotels_table.end());
}

void MainServer::sort_by_premium_price()
{
    sort(hotels_table.begin(), hotels_table.end(), compare_premium_price);
    if(!sort_order_flag)
        reverse(hotels_table.begin(), hotels_table.end());
}

void MainServer::sort_by_average_price()
{
    sort(hotels_table.begin(), hotels_table.end(), compare_average_price);
    if(!sort_order_flag)
        reverse(hotels_table.begin(), hotels_table.end());
}

void MainServer::sort_by_star()
{
    sort(hotels_table.begin(), hotels_table.end(), compare_star);
    if(!sort_order_flag)
        reverse(hotels_table.begin(), hotels_table.end());
}

void MainServer::sort_by_overall_rating()
{
    sort(hotels_table.begin(), hotels_table.end(), compare_overall_rating);
    if(!sort_order_flag)
        reverse(hotels_table.begin(), hotels_table.end());
}

void MainServer::sort_by_personal_rating()
{
    if(!personal_rating)
    {
        if(logged_in_user->get_user_ratings().size() < 5)
            throw InsufficientRatings();
        calculate_weights();
    }
    sort(hotels_table.begin(), hotels_table.end(), compare_personal_rating);
    if(!sort_order_flag)
        reverse(hotels_table.begin(), hotels_table.end());
}

