
#ifndef A7_MAINSERVER_H
#define A7_MAINSERVER_H

#include <string>
#include <iostream>
#include <fstream>
#include <sstream>
#include <vector>


#include "Hotel.h"
#include "User.h"
#include "BadRequestException.h"
#include "PermissionDeniedException.h"
#include "EmptyException.h"
#include "NotFoundException.h"
#include "NotEnoughRoom.h"
#include "NotEnoughCredit.h"
#include "InsufficientRatings.h"
#include "Filter.h"
#include "CityFilter.h"
#include "PriceRangeFilter.h"
#include "StarRangeFilter.h"
#include "RoomFilter.h"
#include "BudgetFilter.h"

#define EVERY_PART_SEPARATOR ','
#define PROPERTY_SEPARATOR '|'


class MainServer{
public:
    std::vector<Hotel*> hotels_table;
    std::vector<Hotel*> filtered_hotels_table;
    std::vector<User*> all_users;
    std::vector<Filter*> all_filters;
    std::vector<Rating*> all_ratings;
    User* logged_in_user = nullptr;
    bool login_flag = false;
    bool budget_flag = true;
    bool sort_order_flag = true;
    bool personal_rating = false;

public:
    std::vector<std::string> prepare_property_vector(std::string _property_amenities);
    void read_hotel_files(char **argv);
    void read_ratings_file(char **argv);
    Hotel* classify_each_hotel_info(std::vector<std::string> _all_hotel_info);
    Rating* classify_each_rating_info(std::vector<std::string> _all_rating_info);
    void signup(std::string _email, std::string _user_name, unsigned long _password);
    void login(std::string _email, unsigned long _password);
    void logout();
    void increase_credit(double _amount);
    void get_wallet_turnover(int _count);
    void get_hotels();
    void print_each_hotel_info(std::string _unique_id);
    void reserve_room(std::string _hotel_id, std::string _type, int _quantity, int _check_in, int _check_out);
    void print_user_reservation();
    void cancel_reservation(int _id);
    void add_comment_for_hotel(std::string _id, std::string _comment);
    void print_comments_of_hotel(std::string _id);
    void add_rating_for_hotel(std::string _id, double _location, double _cleanliness, double _staff, double _facilities, double _value_money, double _overall_rating);
    void add_rating_for_user(std::string _id, double _location, double _cleanliness, double _staff, double _facilities, double _value_money, double _overall_rating);
    void print_average_rating(std::string _id);
    void apply_filters();
    void filter_by_city(std::string _city);
    void filter_by_star(double _min_star, double _max_star);
    void filter_by_price(double _min_price, double _max_price);
    void filter_by_room(std::string type, int quantity, int check_in, int check_out);
    void filtered_by_budget();
    void instructions_for_post_info(std::vector<std::string> _separated_instructions);
    void instructions_for_get_info(std::vector<std::string> _separated_instructions);
    void instruction_for_delete_info(std::vector<std::string> _separated_instructions);
    void manage_signup_instruction(std::vector<std::string> _separated_instructions);
    void manage_login_instruction(std::vector<std::string> _separated_instructions);
    void manage_wallet_instruction(std::vector<std::string> _separated_instructions);
    void manage_count_instruction(std::vector<std::string> _separated_instructions);
    void manage_one_hotel_info_instruction(std::vector<std::string> _separated_instructions);
    void manage_reservation_instruction(std::vector<std::string> _separated_instructions);
    void manage_cancel_reservation(std::vector<std::string> _separated_instructions);
    void manage_add_comment_instruction(std::vector<std::string> _separated_instructions);
    void manage_add_rating_instruction(std::vector<std::string> _separated_instructions);
    void manage_print_comment_instruction(std::vector<std::string> _separated_instructions);
    void manage_print_rating_instruction(std::vector<std::string> _separated_instructions);
    void manage_add_filters(std::vector<std::string> _separated_instructions);
    void manage_city_filters_instruction(std::vector<std::string> _separated_instructions);
    void manage_star_filter_instruction(std::vector<std::string> _separated_instructions);
    void manage_price_filter_instruction(std::vector<std::string> _separated_instructions);
    void manage_room_filter_instruction(std::vector<std::string> _separated_instructions);
    void manage_budget_filter_instruction(std::vector<std::string> _separated_instructions);
    void manage_sort_instruction(std::vector<std::string> _separated_instructions);
    void manage_sort_property(const std::string& _property);
    void manage_post_weights_instruction(std::vector<std::string> _separated_instructions);
    void collect_weights(std::vector<std::string> _separated_instructions);
    void calculate_weights();
    void print_weights();
    void print_estimated_weights();
    void sort_by_id();
    void sort_by_name();
    void sort_by_city();
    void sort_by_standard_price();
    void sort_by_deluxe_price();
    void sort_by_luxury_price();
    void sort_by_premium_price();
    void sort_by_average_price();
    void sort_by_star();
    void sort_by_overall_rating();
    void sort_by_personal_rating();


    void get_instructions();
};

#endif
